// Existing public QuoteCompare offline calculation and CSV import functions.
// The adapter exports the functions without changing calculation behavior.
const QC_ENGINE=(()=>{
/** Exact supplier-quote arithmetic for the Worker runtime.
 * BigInt rationals carry every calculation; Number is only used for bounded
 * counts, calendar components and decimal places. No network or persistence.
 */
class InputError extends Error { constructor(message) { super(message); this.name = 'InputError'; } }

const NUMBER = /^(?:0|[1-9][0-9]{0,14})(?:\.[0-9]{1,9})?$/;
const ID = /^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$/;
const MINOR_UNITS = Object.freeze(Object.fromEntries([
  ...'USD EUR GBP CAD AUD NZD CHF CNY INR SGD HKD MXN BRL ZAR SEK NOK DKK PLN CZK AED SAR ILS THB MYR PHP IDR TRY RON HUF'.split(' ').map(c => [c, 2]),
  ...'JPY KRW CLP VND'.split(' ').map(c => [c, 0]),
  ...'BHD KWD JOD OMR TND'.split(' ').map(c => [c, 3]),
]));
const UNITS = {
  each:['count','each','1'],ea:['count','each','1'],piece:['count','each','1'],pieces:['count','each','1'],
  g:['mass','g','1'],kg:['mass','g','1000'],mg:['mass','g','0.001'],lb:['mass','g','453.59237'],oz:['mass','g','28.349523125'],
  ml:['volume','ml','1'],l:['volume','ml','1000'],us_gal:['volume','ml','3785.411784'],imperial_gal:['volume','ml','4546.09'],
  us_fl_oz:['volume','ml','29.5735295625'],imperial_fl_oz:['volume','ml','28.4130625'],
  mm:['length','mm','1'],cm:['length','mm','10'],m:['length','mm','1000'],in:['length','mm','25.4'],ft:['length','mm','304.8'],
};
const gcd = (a,b) => { a = a < 0n ? -a : a; while(b) [a,b] = [b,a%b]; return a; };
const pow10 = p => 10n ** BigInt(p);
class Rational {
  constructor(n,d=1n) { if(d===0n) throw new Error('Division by zero'); if(d<0n) { n=-n; d=-d; } const g=gcd(n,d); this.n=n/g; this.d=d/g; }
  static decimal(s) { const [whole,fraction='']=s.split('.'); return new Rational(BigInt(whole+fraction),pow10(fraction.length)); }
  add(v) { return new Rational(this.n*v.d+v.n*this.d,this.d*v.d); }
  sub(v) { return new Rational(this.n*v.d-v.n*this.d,this.d*v.d); }
  mul(v) { return new Rational(this.n*v.n,this.d*v.d); }
  div(v) { return new Rational(this.n*v.d,this.d*v.n); }
  cmp(v) { const x=this.n*v.d-v.n*this.d; return x<0n?-1:x>0n?1:0; }
  ceil() { return this.n>=0n?(this.n+this.d-1n)/this.d:this.n/this.d; }
  quantize(places,even=false) {
    const scale=pow10(Math.abs(places)), negative=this.n<0n;
    let n=negative?-this.n:this.n, d=this.d;
    if(places>=0) n*=scale; else d*=scale;
    let q=n/d; const rem=n%d;
    if(rem*2n>d || (rem*2n===d && (!even || q%2n!==0n))) q++;
    if(negative) q=-q;
    return places>=0?new Rational(q,scale):new Rational(q*scale);
  }
  // Match the reference's 80-significant-digit presentation of recurring unit
  // conversions. Financial calculations remain exact until explicit rounding.
  precision80() {
    if(this.n===0n) return this;
    const n=this.n<0n?-this.n:this.n;
    let exponent=n.toString().length-this.d.toString().length;
    if(exponent>=0 ? n < this.d*pow10(exponent) : n*pow10(-exponent)<this.d) exponent--;
    return this.quantize(79-exponent,true);
  }
  fixed(places) {
    const r=this.quantize(places), scale=pow10(places);
    let integer=r.n*scale/r.d; const negative=integer<0n;
    if(negative) integer=-integer;
    const digits=integer.toString().padStart(places+1,'0');
    return (negative?'-':'')+(places?digits.slice(0,-places)+'.'+digits.slice(-places):digits);
  }
  plain() {
    const r=this.precision80(); let denominator=r.d,twos=0,fives=0;
    while(denominator%2n===0n) { denominator/=2n; twos++; }
    while(denominator%5n===0n) { denominator/=5n; fives++; }
    const places=Math.max(twos,fives), text=r.fixed(places);
    return text.includes('.')?text.replace(/0+$/,'').replace(/\.$/,''):text;
  }
}
const ZERO=new Rational(0n), HUNDRED=new Rational(100n);
const clone = value => structuredClone(value);
const isObject = value => value!==null && typeof value==='object' && !Array.isArray(value);
const object = (value,path) => { if(!isObject(value)) throw new InputError(`${path}: expected an object`); return value; };
function fields(value,allowed,path) { const extra=Object.keys(value).filter(k=>!allowed.includes(k)).sort(); if(extra.length) throw new InputError(`${path}: unsupported fields ${extra.join(', ')}; record unmodeled conditions in unresolved_terms`); }
function text(value,path,maximum=500,required=true) { if(value==null&&!required) return null; if(typeof value!=='string'||(required&&!value.trim())||[...value].length>maximum) throw new InputError(`${path}: expected text of 1–${maximum} characters`); return value; }
function identifier(value,path) { if(typeof value!=='string'||!ID.test(value)||value!==value.trim()) throw new InputError(`${path}: expected an identifier using letters, digits, _, -, or .`); return value; }
function number(value,path,{positive=false,percent=false}={}) { if(typeof value!=='string'||!NUMBER.test(value)||value!==value.trim()) throw new InputError(`${path}: use a nonnegative decimal string, without commas or exponent`); const r=Rational.decimal(value); if(positive&&r.cmp(ZERO)<=0) throw new InputError(`${path}: must be greater than zero`); if(percent&&r.cmp(HUNDRED)>0) throw new InputError(`${path}: must be between 0 and 100`); return r; }
const optionalNumber = (value,path,options) => value==null?null:number(value,path,options);
function integer(value,path,minimum=0) { if(!Number.isInteger(value)||value<minimum||value>1e9) throw new InputError(`${path}: expected an integer from ${minimum} to 1000000000`); return value; }
function date(value,path,optional=false) {
  if(value==null&&optional) return null;
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value)||value!==value.trim()) throw new InputError(`${path}: expected YYYY-MM-DD`);
  const [y,m,d]=value.split('-').map(Number), leap=y%4===0&&(y%100!==0||y%400===0);
  const days=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31];
  if(y<1||m<1||m>12||d<1||d>days[m-1]) throw new InputError(`${path}: invalid calendar date`);
  return value;
}
function unit(value,path) { if(typeof value!=='string'||!Object.hasOwn(UNITS,value)) throw new InputError(`${path}: unsupported or ambiguous unit; use ${Object.keys(UNITS).join(', ')}`); const [dimension,base,factor]=UNITS[value]; return [value,dimension,base,Rational.decimal(factor)]; }
function source(value,path) {
  if(value==null) return null; object(value,path);
  const extra=Object.keys(value).filter(k=>!['label','locator','text','url'].includes(k)).sort();
  if(extra.length) throw new InputError(`${path}: unsupported fields ${extra.join(', ')}`);
  const result={label:text(value.label,`${path}.label`,300)};
  for(const [key,limit] of [['locator',300],['text',4000],['url',2000]]) if(value[key]!=null) result[key]=text(value[key],`${path}.${key}`,limit);
  if(result.url!==undefined) {
    let url; try { url=new URL(result.url); } catch { throw new InputError(`${path}.url: malformed source URL`); }
    if(!['http:','https:'].includes(url.protocol)||!url.hostname||url.username||url.password) throw new InputError(`${path}.url: expected a public HTTP(S) source URL without credentials`);
  }
  return result;
}
const money = (value,minor) => value===null?null:value.fixed(minor);
const issue = (code,message,itemId) => itemId===undefined?{code,message}:{code,message,item_id:itemId};

function requirements(document) {
  const items=document.requirements;
  if(!Array.isArray(items)||items.length<1||items.length>500) throw new InputError('requirements: provide 1–500 requested items');
  const result=new Map();
  items.forEach((raw,index)=>{
    const path=`requirements[${index}]`; object(raw,path); fields(raw,['item_id','label','quantity','unit','source'],path);
    const itemId=identifier(raw.item_id,path+'.item_id');
    if(result.has(itemId)) throw new InputError(path+'.item_id: duplicate requested item');
    const quantity=number(raw.quantity,path+'.quantity',{positive:true}), [name,dimension,base,factor]=unit(raw.unit,path+'.unit');
    if(dimension==='count'&&quantity.d!==1n) throw new InputError(path+'.quantity: individual items must be a whole number');
    result.set(itemId,{item_id:itemId,label:text(raw.label===undefined?itemId:raw.label,path+'.label',300),quantity,unit:name,dimension,base_unit:base,factor,source:source(raw.source,path+'.source'),input:clone(raw)});
  });
  return result;
}
function line(raw,requirement,path,minor) {
  object(raw,path); fields(raw,['line_id','item_id','pack_quantity','unit','price_per_pack','minimum_packs','order_increment_packs','discount_percent','source'],path);
  const lineId=identifier(raw.line_id,path+'.line_id'), itemId=identifier(raw.item_id,path+'.item_id');
  const packQuantity=number(raw.pack_quantity,path+'.pack_quantity',{positive:true}), [name,dimension,base,factor]=unit(raw.unit,path+'.unit');
  if(dimension==='count'&&packQuantity.d!==1n) throw new InputError(path+'.pack_quantity: individual items must be a whole number');
  const price=optionalNumber(raw.price_per_pack,path+'.price_per_pack'), discount=optionalNumber(raw.discount_percent,path+'.discount_percent',{percent:true});
  const minimum=raw.minimum_packs==null?null:integer(raw.minimum_packs,path+'.minimum_packs'), increment=raw.order_increment_packs==null?null:integer(raw.order_increment_packs,path+'.order_increment_packs',1);
  const evidence=source(raw.source,path+'.source');
  const result={line_id:lineId,item_id:itemId,source:evidence,input:clone(raw),dimension,base_unit:base,pack_quantity:raw.pack_quantity,pack_unit:name,price_per_pack:price===null?null:raw.price_per_pack,discount_percent:discount===null?null:raw.discount_percent,minimum_packs:minimum,order_increment_packs:increment,packs_ordered:null,quantity_supplied:null,oversupply:null,requested_quantity:null,requested_unit:null,gross:null,discount_amount:null,subtotal:null,unit_cost:null,issues:[]};
  const issues=result.issues;
  if(evidence===null) issues.push(issue('missing_line_source','Add a source label for this quote line.',itemId));
  if(!requirement) { issues.push(issue('unrequested_item','This quoted item is outside the requested basket; confirm its scope.',itemId)); return [result,null]; }
  Object.assign(result,{requested_quantity:requirement.input.quantity,requested_unit:requirement.unit});
  if(dimension!==requirement.dimension) { issues.push(issue('incompatible_unit','Quoted and requested quantities use different dimensions.',itemId)); return [result,null]; }
  for(const [value,code,label] of [[price,'unknown_price','pack price'],[discount,'unknown_line_discount','line discount'],[minimum,'unknown_minimum','minimum order quantity'],[increment,'unknown_increment','order increment']]) if(value===null) issues.push(issue(code,`Confirm the ${label}; use an explicit zero where appropriate.`,itemId));
  if(minimum===null||increment===null) return [result,null];
  const quantityBase=requirement.quantity.mul(requirement.factor), packBase=packQuantity.mul(factor), requiredPacks=quantityBase.div(packBase).ceil();
  let packs=requiredPacks>BigInt(minimum)?requiredPacks:BigInt(minimum);
  packs=(packs+BigInt(increment)-1n)/BigInt(increment)*BigInt(increment);
  if(packs>1000000000n) throw new InputError(path+': resulting pack order exceeds 1000000000; check quantity and units');
  const supplied=new Rational(packs).mul(packBase).div(requirement.factor).precision80();
  Object.assign(result,{packs_ordered:Number(packs),quantity_supplied:supplied.plain(),oversupply:supplied.sub(requirement.quantity).precision80().plain(),pack_in_requested_units:packBase.div(requirement.factor).precision80().plain()});
  if(price===null) return [result,null];
  const gross=price.mul(new Rational(packs)).quantize(minor); result.gross=money(gross,minor);
  if(discount===null) return [result,null];
  const discountAmount=gross.mul(discount).div(HUNDRED).quantize(minor), subtotal=gross.sub(discountAmount);
  Object.assign(result,{discount_amount:money(discountAmount,minor),subtotal:money(subtotal,minor),unit_cost:subtotal.div(supplied).fixed(6)});
  return [result,subtotal];
}
function quote(raw,requirements,asOf,index) {
  const path=`quotes[${index}]`; object(raw,path); fields(raw,['quote_id','supplier','currency','valid_until','source','lines','shipping','fees','discount_percent','tax','unresolved_terms'],path);
  const quoteId=identifier(raw.quote_id,path+'.quote_id'), supplier=text(raw.supplier,path+'.supplier',300), currency=raw.currency;
  if(typeof currency!=='string'||!Object.hasOwn(MINOR_UNITS,currency)) throw new InputError(path+'.currency: unsupported currency; provide a supported uppercase ISO code');
  const minor=MINOR_UNITS[currency], evidence=source(raw.source,path+'.source'), validUntil=date(raw.valid_until,path+'.valid_until',true), issues=[];
  if(evidence===null) issues.push(issue('missing_quote_source',"Add a source label for the supplier's quote."));
  if(validUntil===null) issues.push(issue('unknown_validity',"Confirm the quote's validity date."));
  else if(validUntil<asOf) issues.push(issue('expired_quote',`Quote expired on ${validUntil}.`));
  if(!Array.isArray(raw.lines)||raw.lines.length<1||raw.lines.length>500) throw new InputError(path+'.lines: provide 1–500 quoted items');
  const rows=[], values=[], seen=new Set(), seenLineIds=new Set();
  raw.lines.forEach((entry,index)=>{
    const linePath=`${path}.lines[${index}]`; object(entry,linePath);
    const itemId=identifier(entry.item_id,linePath+'.item_id'), lineId=identifier(entry.line_id,linePath+'.line_id');
    if(seen.has(itemId)) throw new InputError(linePath+'.item_id: duplicate; model alternatives as separate quotes');
    if(seenLineIds.has(lineId)) throw new InputError(linePath+'.line_id: duplicate line identifier');
    seen.add(itemId); seenLineIds.add(lineId);
    const [row,value]=line(entry,requirements.get(itemId),linePath,minor); rows.push(row); values.push(value); issues.push(...row.issues);
  });
  for(const itemId of [...requirements.keys()].filter(k=>!seen.has(k)).sort()) issues.push(issue('missing_item','Supplier has not priced this requested item.',itemId));
  const merchandise=values.every(v=>v!==null)&&seen.size===requirements.size&&[...requirements.keys()].every(k=>seen.has(k))?values.reduce((a,b)=>a.add(b),ZERO):null;
  const orderDiscount=optionalNumber(raw.discount_percent,path+'.discount_percent',{percent:true});
  if(orderDiscount===null) issues.push(issue('unknown_order_discount','Confirm the order discount, including explicit zero.'));
  const discountAmount=merchandise!==null&&orderDiscount!==null?merchandise.mul(orderDiscount).div(HUNDRED).quantize(minor):null;
  const discounted=discountAmount!==null?merchandise.sub(discountAmount):null;
  const shippingRaw=raw.shipping;
  if(shippingRaw!=null) { object(shippingRaw,path+'.shipping'); fields(shippingRaw,['amount','source'],path+'.shipping'); }
  let shipping=optionalNumber(shippingRaw?.amount,path+'.shipping.amount');
  const shippingSource=source(shippingRaw?.source,path+'.shipping.source');
  shipping=shipping===null?null:shipping.quantize(minor);
  if(shipping===null) issues.push(issue('unknown_shipping','Confirm shipping; enter zero only when it is included or waived.'));
  const feesRaw=raw.fees, feeRows=[]; let fees=null;
  if(feesRaw==null) issues.push(issue('unknown_fees','Confirm other charges; an empty list means none.'));
  else if(!Array.isArray(feesRaw)||feesRaw.length>100) throw new InputError(path+'.fees: expected a list of at most 100 charges');
  else { fees=ZERO; feesRaw.forEach((fee,index)=>{
    const feePath=`${path}.fees[${index}]`; object(fee,feePath); fields(fee,['label','amount','source'],feePath);
    const amount=optionalNumber(fee.amount,feePath+'.amount'), label=text(fee.label,feePath+'.label',300), feeSource=source(fee.source,feePath+'.source');
    if(amount===null) { issues.push(issue('unknown_fee_amount',`Confirm the amount of ${label}.`)); fees=null; }
    else if(fees!==null) fees=fees.add(amount.quantize(minor));
    feeRows.push({label,amount:money(amount,minor),source:feeSource});
  }); }
  const taxRaw=raw.tax??{mode:'unknown'}; object(taxRaw,path+'.tax'); fields(taxRaw,['mode','rate_percent','amount','applies_to_shipping','applies_to_fees','source'],path+'.tax');
  const taxMode=taxRaw.mode===undefined?'unknown':taxRaw.mode;
  if(!['none','inclusive','exclusive','amount','unknown'].includes(taxMode)) throw new InputError(path+'.tax.mode: expected none, inclusive, exclusive, amount, or unknown');
  const allowedTaxFields={none:['mode','source'],inclusive:['mode','source'],unknown:['mode','source'],amount:['mode','amount','source'],exclusive:['mode','rate_percent','applies_to_shipping','applies_to_fees','source']}[taxMode];
  if(Object.entries(taxRaw).some(([key,value])=>!allowedTaxFields.includes(key)&&value!=null)) throw new InputError(path+'.tax: fields contradict the selected tax mode; use one explicit tax treatment');
  let tax=null;
  if(taxMode==='none'||taxMode==='inclusive') tax=ZERO;
  else if(taxMode==='amount') { tax=optionalNumber(taxRaw.amount,path+'.tax.amount'); tax=tax===null?null:tax.quantize(minor); if(tax===null) issues.push(issue('unknown_tax','Confirm the quoted tax amount.')); }
  else if(taxMode==='exclusive') {
    const rate=optionalNumber(taxRaw.rate_percent,path+'.tax.rate_percent',{percent:true}), shippingTaxable=taxRaw.applies_to_shipping, feesTaxable=taxRaw.applies_to_fees;
    for(const [name,value] of [['applies_to_shipping',shippingTaxable],['applies_to_fees',feesTaxable]]) if(value!=null&&typeof value!=='boolean') throw new InputError(path+'.tax.'+name+': expected true, false, or null');
    if(rate===null) issues.push(issue('unknown_tax_rate','Confirm the tax rate.'));
    if(shipping!==null&&shipping.cmp(ZERO)!==0&&shippingTaxable==null) issues.push(issue('unknown_shipping_tax','Confirm whether shipping is taxable.'));
    if(fees!==null&&fees.cmp(ZERO)!==0&&feesTaxable==null) issues.push(issue('unknown_fee_tax','Confirm whether additional charges are taxable.'));
    const shippingKnown=(shipping!==null&&shipping.cmp(ZERO)===0)||shippingTaxable!=null, feesKnown=(fees!==null&&fees.cmp(ZERO)===0)||feesTaxable!=null;
    if(rate!==null&&discounted!==null&&shipping!==null&&fees!==null&&shippingKnown&&feesKnown) tax=discounted.add(shippingTaxable?shipping:ZERO).add(feesTaxable?fees:ZERO).mul(rate).div(HUNDRED).quantize(minor);
  } else issues.push(issue('unknown_tax','Confirm tax treatment; totals remain provisional until then.'));
  const taxSource=source(taxRaw.source,path+'.tax.source'), unresolved=raw.unresolved_terms===undefined?[]:raw.unresolved_terms;
  if(!Array.isArray(unresolved)||unresolved.length>100) throw new InputError(path+'.unresolved_terms: expected a list of at most 100 terms');
  unresolved.forEach((term,index)=>issues.push(issue('unresolved_term',text(term,`${path}.unresolved_terms[${index}]`,1000))));
  const total=[discounted,shipping,fees,tax].every(v=>v!==null)?discounted.add(shipping).add(fees).add(tax).quantize(minor):null;
  return {quote_id:quoteId,supplier,currency,minor_units:minor,source:evidence,valid_until:validUntil,current:validUntil===null?null:validUntil>=asOf,lines:rows,merchandise_subtotal:money(merchandise,minor),order_discount_percent:orderDiscount===null?null:raw.discount_percent,order_discount_amount:money(discountAmount,minor),discounted_merchandise:money(discounted,minor),shipping:{amount:money(shipping,minor),source:shippingSource},fees:feeRows,fees_total:money(fees,minor),tax:{mode:taxMode,added_amount:money(tax,minor),source:taxSource,input:clone(taxRaw)},calculated_total:money(total,minor),pricing_complete:total!==null,ranking_eligible:total!==null&&issues.length===0,issues,input:clone(raw)};
}

function compareQuotes(document) {
  object(document,'request'); fields(document,['as_of','requirements','quotes'],'request');
  const asOf=date(document.as_of,'as_of'), requested=requirements(document), rawQuotes=document.quotes;
  if(!Array.isArray(rawQuotes)||rawQuotes.length<1||rawQuotes.length>50) throw new InputError('quotes: provide 1–50 supplier quotes');
  const seen=new Set(), quotes=rawQuotes.map((raw,index)=>{
    const result=quote(raw,requested,asOf,index);
    if(seen.has(result.quote_id)) throw new InputError(`quotes[${index}].quote_id: duplicate quote identifier`);
    seen.add(result.quote_id); return result;
  });
  const groups=[...new Set(quotes.map(q=>q.currency))].sort().map(currency=>{
    const group=quotes.filter(q=>q.currency===currency), ranked=group.filter(q=>q.ranking_eligible).sort((a,b)=>Rational.decimal(a.calculated_total).cmp(Rational.decimal(b.calculated_total))||(a.quote_id<b.quote_id?-1:a.quote_id>b.quote_id?1:0));
    const minimum=ranked.length?ranked[0].calculated_total:null, lowest=ranked.filter(q=>q.calculated_total===minimum).map(q=>q.quote_id), excluded=group.filter(q=>!q.ranking_eligible).map(q=>q.quote_id);
    return {currency,ranked_quote_ids:ranked.map(q=>q.quote_id),lowest_complete_quote_ids:lowest,excluded_quote_ids:excluded,all_quotes_comparable:excluded.length===0,overall_lowest_confirmed:ranked.length>0&&excluded.length===0,basis:'Current, fully priced quotes for the full requested basket, in this currency only.'};
  });
  return {schema_version:'1.0.0',as_of:asOf,requirements:[...requested.values()].map(item=>clone(item.input)),quotes,currency_groups:groups,notes:[
    'Currencies are compared separately; exchange rates are never assumed.',
    'An incomplete or expired quote cannot establish the lowest supplier cost.',
    'Order discounts apply to merchandise after line discounts. Tax bases follow the explicit input.',
    'Each extended line, discount, and tax amount is rounded half up to the currency minor unit.',
    'Minimums and order increments apply to whole packs; increments are absolute pack multiples.',
    'Supplier stock, product equivalence, and quote authenticity require source review.',
  ]};
}
function csvSafe(value) { let text=value==null?'':typeof value==='boolean'?(value?'True':'False'):String(value); return /^[=+\-@\t\r]/.test(text.trimStart())?"'"+text:text; }
function csvRow(values) { return values.map(csvSafe).map(v=>/[",\r\n]/.test(v)?'"'+v.replaceAll('"','""')+'"':v).join(',')+'\r\n'; }
function comparisonCsv(result) {
  let output=csvRow(['quote_id','supplier','currency','quote_total','ranking_eligible','valid_until','item_id','requested_quantity','requested_unit','packs_ordered','quantity_supplied','oversupply','line_subtotal','line_unit_cost_excl_order_charges','issues','source_label','source_locator','source_url']);
  for(const quote of result.quotes) for(const line of quote.lines) {
    const source=line.source||quote.source||{};
    output+=csvRow([quote.quote_id,quote.supplier,quote.currency,quote.calculated_total,quote.ranking_eligible,quote.valid_until,line.item_id,line.requested_quantity,line.requested_unit,line.packs_ordered,line.quantity_supplied,line.oversupply,line.subtotal,line.unit_cost,quote.issues.map(i=>i.message).join('; '),source.label,source.locator,source.url]);
  }
  return output;
}

return {InputError,MINOR_UNITS,compareQuotes,comparisonCsv};
})();
const QC_IMPORT=(()=>{
/** Deliberately small CSV interchange; empty fields stay unknown. */
const {InputError}=QC_ENGINE;
const HEADERS = ['quote_id','supplier','currency','valid_until','quote_source','item_id','item','required_quantity','required_unit','pack_quantity','pack_unit','price_per_pack','minimum_packs','order_increment_packs','line_discount_percent','order_discount_percent','shipping','other_fees','tax_mode','tax_value','tax_shipping','tax_fees','line_source'];

function parseRows(text) {
  if (typeof text !== 'string' || new TextEncoder().encode(text).length > 2000000) throw new InputError('CSV must be text under 2 MB');
  text = text.replace(/^\uFEFF/, '');
  const rows=[]; let row=[],field='',quoted=false,closed=false;
  for(let i=0;i<text.length;i++) {
    const c=text[i];
    if(quoted) {
      if(c==='"') { if(text[i+1]==='"') {field+='"';i++;} else {quoted=false;closed=true;} }
      else field+=c;
    } else if(c===',') {row.push(field);field='';closed=false;}
    else if(c==='\r'||c==='\n') { if(c==='\r'&&text[i+1]==='\n') i++;row.push(field);rows.push(row);row=[];field='';closed=false; }
    else if(c==='"' && field==='' && !closed) quoted=true;
    else if(closed || c==='"') throw new InputError('CSV has malformed quoting; quote a complete field and double embedded quotation marks');
    else field+=c;
    if(rows.length>5001) throw new InputError('CSV has more than 5,000 lines');
  }
  if(quoted) throw new InputError('CSV ends inside a quoted field');
  if(field!==''||row.length||closed) {row.push(field);rows.push(row);}
  return rows;
}

function importCsv(text,asOf) {
  const rows=parseRows(text), fields=rows.shift();
  if(!fields?.length||new Set(fields).size!==fields.length) throw new InputError('CSV needs a single header row with unique column names');
  const missing=HEADERS.filter(x=>!fields.includes(x));
  if(missing.length) throw new InputError('CSV is missing columns: '+missing.sort().join(', '));
  const quotes=new Map(),requirements=new Map();
  rows.forEach((values,index)=>{
    const number=index+2;
    if(values.length>fields.length) throw new InputError(`CSV row ${number}: too many columns; quote fields containing commas`);
    if(!values.some(x=>x.trim())) return;
    const row=Object.fromEntries(fields.map((field,i)=>[field,values[i]?.trim()||null]));
    const integer=name=>{const value=row[name];if(value===null)return null;if(!/^\d+$/.test(value)||!Number.isSafeInteger(Number(value)))throw new InputError(`CSV row ${number}, ${name}: use a whole nonnegative number`);return Number(value);};
    const bool=name=>{const value=row[name];if(value===null)return null;if(!/^(true|false)$/i.test(value))throw new InputError(`CSV row ${number}, ${name}: use true, false, or leave blank`);return value.toLowerCase()==='true';};
    const itemId=row.item_id,quoteId=row.quote_id;
    const requirement={item_id:itemId,label:row.item,quantity:row.required_quantity,unit:row.required_unit};
    if(requirements.has(itemId)&&JSON.stringify(requirements.get(itemId))!==JSON.stringify(requirement))throw new InputError(`CSV row ${number}: conflicting requirement for ${itemId}`);
    requirements.set(itemId,requirement);
    const tax={mode:row.tax_mode||'unknown'};
    if(tax.mode==='amount') tax.amount=row.tax_value;
    if(tax.mode==='exclusive') Object.assign(tax,{rate_percent:row.tax_value,applies_to_shipping:bool('tax_shipping'),applies_to_fees:bool('tax_fees')});
    const quote={quote_id:quoteId,supplier:row.supplier,currency:row.currency,valid_until:row.valid_until,source:row.quote_source?{label:row.quote_source}:null,shipping:{amount:row.shipping},fees:row.other_fees!==null?[{label:'Other charges',amount:row.other_fees}]:null,discount_percent:row.order_discount_percent,tax};
    if(quotes.has(quoteId)) {const {lines,...previous}=quotes.get(quoteId);if(JSON.stringify(previous)!==JSON.stringify(quote))throw new InputError(`CSV row ${number}: conflicting order terms for quote ${quoteId}`);}
    else quotes.set(quoteId,{...quote,lines:[]});
    quotes.get(quoteId).lines.push({line_id:`line${number}`,item_id:itemId,pack_quantity:row.pack_quantity,unit:row.pack_unit,price_per_pack:row.price_per_pack,minimum_packs:integer('minimum_packs'),order_increment_packs:integer('order_increment_packs'),discount_percent:row.line_discount_percent,source:row.line_source?{label:row.line_source}:null});
  });
  return {as_of:asOf,requirements:[...requirements.values()],quotes:[...quotes.values()]};
}

function templateCsv() {
  return HEADERS.join(',')+'\r\n'+['supplier-a','Example supplier A','USD','','','gloves','Work gloves','100','each','12','each','18.00','1','1','0','0','12.00','0','unknown','','','',''].join(',')+'\r\n';
}

return {HEADERS,importCsv,templateCsv,parseRows};
})();

export const {InputError,MINOR_UNITS,compareQuotes,comparisonCsv}=QC_ENGINE;
export const {HEADERS,importCsv,templateCsv,parseRows}=QC_IMPORT;
