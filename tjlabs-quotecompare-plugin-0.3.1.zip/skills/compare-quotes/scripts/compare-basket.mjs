#!/usr/bin/env node
import { readFile, writeFile, mkdir, stat } from 'node:fs/promises';
import { basename, extname, join, resolve } from 'node:path';
import { InputError, HEADERS, compareQuotes, comparisonCsv, importCsv, templateCsv, parseRows } from './basket-core.mjs';

const usage = `QuoteCompare: local whole-pack and minimum-order comparison

Usage:
  node compare-basket.mjs INPUT.json [--as-of YYYY-MM-DD] [--name NAME] [--out NEW_DIRECTORY]
  node compare-basket.mjs INPUT.csv --csv --as-of YYYY-MM-DD [--name NAME] [--out NEW_DIRECTORY]
  node compare-basket.mjs --template NEW_FILE.csv

With --out, write workbench.html, project.json and comparison.csv to a new directory.
Without --out, write the full calculated result as JSON to standard output.
Read the reference before converting source quotations. Leave unknown charges blank or null.
The calculation and generated workbench use no network connection. Node.js 18+ is required.
`;

function argumentsFor(args) {
  if (args.length === 1 && ['--help', '-h'].includes(args[0])) return { help: true };
  const options = {};
  const names = new Map([['--as-of', 'asOf'], ['--name', 'name'], ['--out', 'out'], ['--template', 'template']]);
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--csv') {
      if (options.csv) throw new InputError('Use --csv only once.');
      options.csv = true;
    } else if (names.has(arg)) {
      const name = names.get(arg);
      if (Object.hasOwn(options, name)) throw new InputError(`Use ${arg} only once.`);
      const value = args[++i];
      if (!value || value.startsWith('--')) throw new InputError(`${arg} requires a value.`);
      options[name] = value;
    } else if (arg.startsWith('-') || options.input) {
      throw new InputError(`Unexpected argument: ${arg}`);
    } else options.input = arg;
  }
  if (options.template) {
    if (Object.keys(options).length !== 1) throw new InputError('--template is a separate command.');
  } else {
    if (!options.input) throw new InputError('Provide an input file.');
    if (options.csv && !options.asOf) throw new InputError('CSV needs an explicit --as-of YYYY-MM-DD comparison date.');
    if (!options.csv && extname(options.input).toLowerCase() === '.csv') throw new InputError('Use --csv and --as-of for the basket template CSV format.');
  }
  return options;
}

function importTemplateCsv(text, asOf) {
  const rows = parseRows(text);
  const header = rows[0] || [];
  if (!header.length || new Set(header).size !== header.length) throw new InputError('CSV needs a single header row with unique column names.');
  const missing = HEADERS.filter(name => !header.includes(name));
  if (missing.length) throw new InputError(`CSV is missing columns: ${missing.sort().join(', ')}`);
  const extras = header.filter(name => !HEADERS.includes(name));
  if (extras.length) throw new InputError(`CSV has unsupported columns: ${extras.join(', ')}. Use project JSON for additional source references and unresolved terms.`);
  // Keep optional columns from silently hiding a tax term that the mode cannot use.
  for (let index = 1; index < rows.length; index++) {
    const values = rows[index];
    if (!values.some(value => value.trim())) continue;
    const row = Object.fromEntries(header.map((name, col) => [name, values[col]?.trim() || null]));
    const mode = row.tax_mode || 'unknown';
    if (!['amount', 'exclusive'].includes(mode) && row.tax_value !== null) {
      throw new InputError(`CSV row ${index + 1}: tax_value applies only to amount or exclusive tax. Preserve the actual tax treatment.`);
    }
    if (mode !== 'exclusive' && (row.tax_shipping !== null || row.tax_fees !== null)) {
      throw new InputError(`CSV row ${index + 1}: tax_shipping and tax_fees apply only to exclusive tax.`);
    }
  }
  return importCsv(text, asOf);
}

function projectName(value) {
  if (typeof value !== 'string' || !value.trim() || [...value].length > 150) {
    throw new InputError('project_name / --name must be nonempty text of at most 150 characters.');
  }
  return value;
}

function scriptJson(document) {
  return JSON.stringify(document).replace(/[<>&\u2028\u2029]/g, character => ({
    '<': '\\u003c', '>': '\\u003e', '&': '\\u0026', '\u2028': '\\u2028', '\u2029': '\\u2029',
  }[character]));
}

async function workbenchFor(project) {
  const template = await readFile(new URL('../assets/pack-workbench.html', import.meta.url), 'utf8');
  const expression = /(<script type="application\/json" id="qc-initial-project">)[\s\S]*?(<\/script>)/g;
  if ([...template.matchAll(expression)].length !== 1) throw new Error('The packaged workbench must contain exactly one initial project.');
  return template.replace(expression, (_match, before, after) => before + scriptJson(project) + after);
}

async function main() {
  const options = argumentsFor(process.argv.slice(2));
  if (options.help) { process.stdout.write(usage); return; }
  if (options.template) {
    const destination = resolve(options.template);
    await writeFile(destination, templateCsv(), { encoding: 'utf8', flag: 'wx' });
    process.stdout.write(`Created basket CSV template: ${destination}\n`);
    return;
  }
  const inputPath = resolve(options.input);
  const inputStat = await stat(inputPath);
  if (!inputStat.isFile() || inputStat.size > 2000000) throw new InputError('Choose a regular input file of at most 2 MB.');
  const text = await readFile(inputPath, 'utf8');
  const supplied = options.csv ? importTemplateCsv(text, options.asOf) : JSON.parse(text.replace(/^\uFEFF/, ''));
  if (!supplied || typeof supplied !== 'object' || Array.isArray(supplied)) throw new InputError('Basket input must be an object with as_of, requirements, and quotes.');
  const { project_name: savedName, ...document } = supplied;
  if (options.asOf) document.as_of = options.asOf;
  const name = projectName(options.name ?? savedName ?? basename(inputPath, extname(inputPath)));
  const result = compareQuotes(document);
  if (!options.out) { process.stdout.write(JSON.stringify(result, null, 2) + '\n'); return; }

  const project = { project_name: name, ...document };
  const html = await workbenchFor(project);
  const csv = comparisonCsv(result);
  const folder = resolve(options.out);
  // Validate and render before creating output. A new folder prevents overwriting
  // an accepted comparison, an edited project, or an earlier customer delivery.
  await mkdir(folder);
  const files = [
    ['workbench.html', html],
    ['project.json', JSON.stringify(project, null, 2) + '\n'],
    ['comparison.csv', csv],
  ];
  for (const [filename, content] of files) await writeFile(join(folder, filename), content, { encoding: 'utf8', flag: 'wx' });
  process.stdout.write(JSON.stringify({
    comparison: name,
    as_of: result.as_of,
    files: Object.fromEntries(files.map(([filename]) => [filename, join(folder, filename)])),
    quotes: result.quotes.map(quote => ({
      quote_id: quote.quote_id, supplier: quote.supplier, currency: quote.currency,
      calculated_total: quote.calculated_total, ranking_eligible: quote.ranking_eligible,
      issues: quote.issues.map(issue => issue.message),
    })),
    currency_groups: result.currency_groups,
  }, null, 2) + '\n');
}

main().catch(error => {
  const message = error.code === 'EEXIST'
    ? `Output already exists: ${error.path}. Choose a new file or directory to preserve the existing comparison.`
    : error.message;
  process.stderr.write(`Quote comparison failed: ${message}\n`);
  if (error instanceof InputError) process.stderr.write('Use --help for command examples.\n');
  process.exitCode = 1;
});
