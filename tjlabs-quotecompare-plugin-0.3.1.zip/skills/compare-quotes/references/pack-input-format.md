# Basket and pack comparison

Use this format for explicit purchase requirements, pack sizes, supplier minimums, order increments and separate line/order discounts. The local `compare-basket.mjs` command and hosted tools share the basket object: `as_of`, `requirements`, and `quotes`. The separate unit-price CLI uses a different format.

Start from [pack-example.json](../assets/pack-example.json), a fictional event-supply basket. Use the actual comparison date. Preserve the real validity dates on source quotations.

## JSON input

| Field | Meaning |
| --- | --- |
| `as_of` | Required comparison date, `YYYY-MM-DD`. |
| `requirements` | Array of requested items with `item_id`, positive decimal-string `quantity`, and explicit `unit`. Optional `label` and `source` preserve the buyer's requirement. |
| `quotes` | Array of supplier quotations with the fields below. |
| `project_name` | Optional local saved-project name, at most 150 characters. The CLI removes it before calculation. Omit it from hosted tool arguments. |

Each quote contains `quote_id`, `supplier`, `currency` and `lines`, plus its known `valid_until`, `source`, `shipping`, `fees`, `discount_percent`, `tax` and `unresolved_terms`.

Each line contains:

| Field | Meaning |
| --- | --- |
| `line_id`, `item_id` | Unique line identifier and its matching buyer requirement. |
| `pack_quantity`, `unit` | Amount of an explicit unit in one purchasable pack. |
| `price_per_pack` | Exact decimal-string pack price; null when unknown. |
| `minimum_packs` | Minimum whole packs; integer or null when unknown. |
| `order_increment_packs` | Order quantity must be an absolute multiple of this many packs; positive integer or null. |
| `discount_percent` | Explicit line discount as decimal text; null when unknown. |
| `source` | Source label and optional `locator`, `text` excerpt, or public HTTP(S) `url`. |

Supply monetary amounts, percentage rates and quantities as decimal strings, without commas or exponents. Pack counts and increments are integers. Use null for unknowns. Zero requires evidence that a charge or discount is zero. Line discounts apply first; the separate order discount applies to the discounted merchandise.

Supported units include each/ea/piece/pieces; mg/g/kg/lb/oz; ml/l; explicit `us_fl_oz`, `imperial_fl_oz`, `us_gal`, `imperial_gal`; and mm/cm/m/in/ft. Keep mass, volume and length distinct. Do not infer density or assume ambiguous gallons or ounces. Matching units do not establish that products have the same specification.

`shipping` has `amount` and an optional source. `fees` is an array of labelled amounts and sources. Use `[]` only when the source establishes no other charges. `tax.mode` is `none`, `inclusive`, `exclusive`, `amount` or `unknown`. Supply the stated rate or fixed amount and, for exclusive tax, explicit `applies_to_shipping` and `applies_to_fees` booleans. Preserve unsupported conditions in `unresolved_terms` instead of dropping them.

For example, a quoted 8% tax on discounted merchandise and freight, with fees exempt, is:

```json
"tax": {
  "mode": "exclusive",
  "rate_percent": "8",
  "applies_to_shipping": true,
  "applies_to_fees": false,
  "source": {"label": "Supplier quote", "locator": "Tax terms"}
}
```

Use `null` for an unconfirmed tax-base flag. Do not copy this example's rate or treatment into a quote that does not state it. The engine exposes an unresolved tax basis when it can affect the total.

The engine accepts 1–500 requirements, 1–50 quotes and 1–500 lines per quote. The CLI limits input files to 2 MB. These technical limits do not change the agreed scope of the lab's paid preparation service.

## Template CSV

Generate the basket template instead of adapting a differently shaped CSV:

```bash
node scripts/compare-basket.mjs --template quotes.csv
node scripts/compare-basket.mjs quotes.csv --csv --as-of 2026-10-26 --out comparison
```

The required 23-column header is:

```csv
quote_id,supplier,currency,valid_until,quote_source,item_id,item,required_quantity,required_unit,pack_quantity,pack_unit,price_per_pack,minimum_packs,order_increment_packs,line_discount_percent,order_discount_percent,shipping,other_fees,tax_mode,tax_value,tax_shipping,tax_fees,line_source
```

Use one row per supplier/item line. Repeat the same requirement and order-level terms consistently across rows for that item or quote. Quote commas and multiline text using standard CSV double quotes. Leave unknown cells blank. Use `true` or `false` for exclusive-tax shipping/fee flags; leave those flags blank for other tax modes. `tax_value` is the stated fixed amount for `amount`, or percentage rate for `exclusive`; leave it blank for other modes.

The template uses `quote_source` and `line_source` as source labels, and `other_fees` as one aggregate amount. Use JSON to preserve multiple named fees, separate source URLs/locators/excerpts, or unresolved commercial conditions. The local CLI rejects extra CSV columns instead of discarding them. Preserve the supplied source data when converting it to either supported format.

## Output and review

With `--out NEW_DIRECTORY`, the CLI writes exactly three files: `workbench.html`, `project.json`, and `comparison.csv`. The output directory must not already exist. Omit `--out` for the full calculation JSON on standard output. `--as-of` explicitly replaces a JSON comparison date when requested, while the original quote validity dates remain intact. `--name` names the saved project.

Open `workbench.html` in a current browser. It contains its input and calculation engine, so calculation needs no server, installation or connection. Save the project after edits; the existing downloaded HTML does not rewrite itself. Reopen `project.json` in the same workbench, or rerun the CLI to create a fresh standalone handoff.

Show required quantity, whole packs purchased, actual quantity supplied, oversupply, charges and total. Keep unresolved terms and exclusion reasons visible. Currency groups remain separate. An incomplete or expired quote cannot establish the lowest supplier cost. Review real product equivalence, stock, terms and the supplier's rounding method alongside the result.

The local CSV is a calculated snapshot with supplier/item rows and source references; editing its cells does not recalculate the basket. `line_subtotal` and `line_unit_cost_excl_order_charges` include the line discount but precede the separate order discount, freight, fees and tax. Unit cost uses the requested unit in `requested_unit`; `quote_total` is the complete order cost when known. The existing hosted export names the same line-level value `unit_cost`. The JSON project retains the complete source-bearing input. The workbench supports recalculation, CSV export, project download, and printing to PDF.

The existing hosted `compare_supplier_quotes` and `export_quote_comparison` tools accept the same basket without `project_name`. They send supplied basket fields to the hosted QuoteCompare service; local commands and generated workbenches calculate on the current device.
