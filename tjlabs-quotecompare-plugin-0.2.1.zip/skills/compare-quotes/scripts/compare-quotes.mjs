#!/usr/bin/env node
import { readFile, writeFile } from 'node:fs/promises';
import { compareQuotes, importCSV } from './core.mjs';

const args = process.argv.slice(2);
const usage = 'Usage: node compare-quotes.mjs INPUT.json [--csv] [--output OUTPUT.json]';
if (args.includes('--help') || args.includes('-h')) {
  process.stdout.write(`${usage}\n`);
  process.exit(0);
}
let inputPath;
let outputPath;
let csv = false;
for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  if (arg === '--csv') csv = true;
  else if (arg === '--output') {
    outputPath = args[++i];
    if (!outputPath || outputPath.startsWith('--')) {
      process.stderr.write(`--output requires a filename.\n${usage}\n`);
      process.exit(2);
    }
  } else if (arg.startsWith('-') || inputPath) {
    process.stderr.write(`Unexpected argument: ${arg}\n${usage}\n`);
    process.exit(2);
  } else inputPath = arg;
}
if (!inputPath) {
  process.stderr.write(`${usage}\n`);
  process.exit(2);
}
try {
  const source = await readFile(inputPath, 'utf8');
  const document = csv ? { quotes: importCSV(source) } : JSON.parse(source);
  const quotes = Array.isArray(document) ? document : document.quotes;
  if (!Array.isArray(quotes)) throw new Error('Input must be an array of quotes or an object containing a quotes array.');
  const result = compareQuotes(quotes);
  const output = `${JSON.stringify(result, null, 2)}\n`;
  if (outputPath) await writeFile(outputPath, output, 'utf8');
  else process.stdout.write(output);
} catch (error) {
  process.stderr.write(`Quote comparison failed: ${error.message}\n`);
  process.exit(1);
}
