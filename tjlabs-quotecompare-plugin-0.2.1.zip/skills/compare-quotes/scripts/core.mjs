// Quote Compare Desk — deterministic arithmetic and portable CSV. No network.
const CURRENCIES = new Set('USD CAD EUR GBP AUD NZD JPY CHF SEK NOK DKK PLN CZK MXN SGD HKD KWD BHD'.split(' '));
const SCALE = 1000000n;
const isBlank = x => x === null || x === undefined || (typeof x === 'string' && !x.trim());
function decimal(x, label, max = 1000000000) {
  if (isBlank(x)) throw new Error(`${label} is unknown`);
  const s = String(x).trim();
  if (!/^\d+(?:\.\d{1,6})?$/.test(s) || Number(s) > max) throw new Error(`${label} must be a nonnegative number with up to six decimals`);
  const [a,b=''] = s.split('.'); return BigInt(a)*SCALE + BigInt(b.padEnd(6,'0'));
}
function roundDiv(a,b) { return (a + b/2n)/b; }
function places(currency) { return new Intl.NumberFormat('en',{style:'currency',currency}).resolvedOptions().maximumFractionDigits; }
function minor(x,label,digits) { return roundDiv(decimal(x,label),10n**BigInt(6-digits)); }
function num(x,digits) { return x === null ? null : Number(x)/10**digits; }
function norm(x) { return String(x||'').trim().toLowerCase().replace(/\s+/g,' '); }

export function compareQuotes(quotes, {asOf = new Date().toISOString().slice(0,10)} = {}) {
  if (!Array.isArray(quotes) || quotes.length > 100) throw new Error('Provide an array of at most 100 quotes');
  const groups = new Map(), issues=[];
  const seen = new Set();
  for (const [index,q] of quotes.entries()) {
    if (!q || typeof q !== 'object') throw new Error(`Quote ${index+1} must be an object`);
    const id = String(q.id||`quote-${index+1}`), vendor=String(q.vendor||'').trim()||`Vendor ${index+1}`;
    if(seen.has(id)) throw new Error(`Duplicate quote id: ${id}`); seen.add(id);
    const currency = String(q.currency||'').toUpperCase().trim();
    const validCurrency = CURRENCIES.has(currency), digits = validCurrency ? places(currency) : 2;
    const errors=[],questions=[],notes=[],lines=[],scope=[];
    if (!validCurrency) errors.push('Choose a supported currency');
    let subtotal=0n, complete=true;
    const active=(Array.isArray(q.items)?q.items:[]).filter(item=>!item.optional||item.included===true);
    if(!Array.isArray(q.items)) errors.push('Line items must be an array');
    if(!active.length) errors.push('Add at least one included line item');
    if(active.length>1000) throw new Error('A quote may contain at most 1000 included items');
    for(const [i,item] of active.entries()) {
      let amount=null;
      const description=String(item.description||'').trim();
      const unit=norm(item.unit);
      if(!description) errors.push(`Line ${i+1}: description is missing`);
      if(!unit) errors.push(`Line ${i+1}: unit is missing`);
      try {
        const quantity=decimal(item.quantity,`Line ${i+1} quantity`);
        if(quantity===0n) throw new Error(`Line ${i+1} quantity must exceed zero`);
        const price=decimal(item.unitPrice,`Line ${i+1} unit price`);
        amount=roundDiv(quantity*price*10n**BigInt(digits),SCALE*SCALE);
        if(amount>900000000000000n) throw new Error(`Line ${i+1} amount exceeds supported range`);
        subtotal+=amount;
        scope.push(`${norm(description)}|${quantity}|${unit}`);
      } catch(e) { errors.push(e.message); complete=false; }
      lines.push({description,quantity:item.quantity,unit:item.unit,unitPrice:item.unitPrice,amount:num(amount,digits),optional:!!item.optional});
    }
    let discountAmount=null,shipping=null,fees=null,tax=null,total=null;
    try {
      const rate=decimal(q.discountPercent,'Discount percent',100);
      discountAmount=roundDiv(subtotal*rate,100n*SCALE);
    } catch(e) { errors.push(e.message); }
    try { shipping=minor(q.shipping,'Shipping',digits); } catch(e){errors.push(e.message);questions.push('What is the shipping or delivery charge?');}
    try { fees=minor(q.fees,'Extra fees',digits); } catch(e){errors.push(e.message);questions.push('Are there setup, handling, installation or other fees?');}
    const taxBase=q.taxBase||'items+fees';
    if(!['items','items+fees','all'].includes(taxBase)) errors.push('Tax base must be items, items+fees, or all');
    try {
      const rate=decimal(q.taxRate,'Tax percent',100);
      if(discountAmount!==null && (taxBase==='items'||fees!==null) && (taxBase!=='all'||shipping!==null)) {
        const base=subtotal-discountAmount+(taxBase!=='items'?(fees??0n):0n)+(taxBase==='all'?(shipping??0n):0n);
        tax=roundDiv(base*rate,100n*SCALE);
      }
    } catch(e){errors.push(e.message);questions.push('What tax rate and taxable components apply to this quote?');}
    if(q.validUntil) {
      if(!/^\d{4}-\d{2}-\d{2}$/.test(q.validUntil)||Number.isNaN(Date.parse(q.validUntil))) notes.push('Validity date is invalid');
      else if(q.validUntil<asOf) {notes.push(`Quote expired ${q.validUntil}`);questions.push('Please refresh the expired quote and confirm current availability.');}
    } else { notes.push('Validity date is unknown'); questions.push('Until when is this price valid?'); }
    if(isBlank(q.leadDays)) {notes.push('Lead time is unknown');questions.push('What is the confirmed delivery or completion lead time?');}
    else if(!/^\d+$/.test(String(q.leadDays))) {notes.push('Lead days must be a nonnegative integer');questions.push('Confirm the delivery lead time in calendar days.');}
    if(!String(q.notes||'').trim()) questions.push('Confirm inclusions, exclusions, warranty and payment terms.');
    complete=complete && errors.length===0 && tax!==null;
    if(complete) total=subtotal-discountAmount+shipping+fees+tax;
    const row={id,vendor,currency,reference:String(q.reference||''),validUntil:q.validUntil||null,leadDays:isBlank(q.leadDays)?null:q.leadDays,
      subtotal:active.length&&lines.every(l=>l.amount!==null)?num(subtotal,digits):null,discountAmount:num(discountAmount,digits),shipping:num(shipping,digits),fees:num(fees,digits),tax:num(tax,digits),total:num(total,digits),complete,
      issues:[...new Set([...errors,...notes])],questions:[...new Set(questions)],lines,taxBase,scopeSignature:scope.sort().join('\n'),notes:String(q.notes||'')};
    const key=validCurrency?currency:'UNKNOWN'; if(!groups.has(key))groups.set(key,{currency:key,quotes:[],scopeComparable:true,scopeNotes:[]});groups.get(key).quotes.push(row);
  }
  for(const group of groups.values()){
    const signatures=new Set(group.quotes.map(q=>q.scopeSignature));
    group.scopeComparable=signatures.size<=1 && group.quotes.every(q=>q.lines.length&&q.lines.every(l=>l.amount!==null));
    if(!group.scopeComparable)group.scopeNotes.push('Scopes differ or are incomplete. Align descriptions, quantities and units before treating totals as equivalent offers.');
    group.quotes.sort((a,b)=>(a.total===null)-(b.total===null)||(a.total??0)-(b.total??0));
  }
  if(groups.size>1)issues.push('Currencies are compared separately. No exchange rate has been assumed.');
  return {asOf,groups:[...groups.values()],issues};
}

export const CSV_COLUMNS = ['id','vendor','currency','reference','validUntil','leadDays','shipping','taxRate','taxBase','fees','discountPercent','notes','itemId','description','quantity','unit','unitPrice','optional','included'];
export function parseCSV(text) {
  text=String(text).replace(/^\uFEFF/,'');if(text.length>10000000)throw new Error('CSV exceeds 10 MB');
  const rows=[];let row=[],field='',quoted=false,after=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(quoted){if(c==='"'){if(text[i+1]==='"'){field+='"';i++;}else{quoted=false;after=true;}}else field+=c;}
    else if(c==='"'){if(field||after)throw new Error('Unexpected quote in CSV');quoted=true;}
    else if(c===','){row.push(field);field='';after=false;}
    else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);if(row.some(x=>x!==''))rows.push(row);row=[];field='';after=false;}
    else {if(after&&!/\s/.test(c))throw new Error('Unexpected text after closing CSV quote'); if(!after)field+=c;}
  }
  if(quoted)throw new Error('Unclosed CSV quote');row.push(field);if(row.some(x=>x!==''))rows.push(row);
  return rows;
}
function csvCell(value){let s=isBlank(value)?'':String(value);if(/^[=+\-@\t\r]/.test(s))s="'"+s;return /[",\r\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;}
export function toCSV(quotes){
  return [CSV_COLUMNS.join(','),...quotes.flatMap(q=>(q.items?.length?q.items:[{}]).map(item=>CSV_COLUMNS.map(k=>csvCell(k==='itemId'?item.id:['description','quantity','unit','unitPrice','optional','included'].includes(k)?item[k]:q[k])).join(',')))].join('\r\n');
}
export function importCSV(text){
  const rows=parseCSV(text);if(!rows.length)throw new Error('CSV is empty');const header=rows.shift().map(x=>x.trim());
  if(new Set(header).size!==header.length)throw new Error('Duplicate CSV column');
  for(const key of ['id','vendor','currency','description','quantity','unit','unitPrice'])if(!header.includes(key))throw new Error(`CSV missing ${key} column`);
  const quotes=new Map();
  for(const [i,row] of rows.entries()){
    if(row.length!==header.length)throw new Error(`CSV row ${i+2} has ${row.length} cells; expected ${header.length}`);
    const data=Object.fromEntries(header.map((key,j)=>[key,row[j]]));
    if(!data.id.trim())throw new Error(`CSV row ${i+2} needs a quote id`);
    const metadata=Object.fromEntries(CSV_COLUMNS.filter(k=>!['itemId','description','quantity','unit','unitPrice','optional','included'].includes(k)).map(k=>[k,data[k]??'']));
    if(!quotes.has(data.id))quotes.set(data.id,{...metadata,items:[]});
    const q=quotes.get(data.id);for(const [key,val]of Object.entries(metadata))if(String(q[key])!==val)throw new Error(`CSV quote ${data.id} has conflicting ${key}`);
    const bool=(key)=>{const v=norm(data[key]);if(!['','true','false','1','0'].includes(v))throw new Error(`CSV row ${i+2}: ${key} must be true or false`);return v==='true'||v==='1';};
    q.items.push({id:data.itemId||`${data.id}-${q.items.length+1}`,description:data.description,quantity:data.quantity,unit:data.unit,unitPrice:data.unitPrice,optional:bool('optional'),included:bool('included')});
  }
  if(!quotes.size)throw new Error('CSV contains no quotes');return [...quotes.values()];
}
