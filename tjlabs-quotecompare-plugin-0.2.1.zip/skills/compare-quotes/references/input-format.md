# Input format

Use a JSON object with a `quotes` array, or a bare quote array. Supply numbers as nonnegative JSON numbers or decimal strings with up to six fractional digits. Leave unknown values `null`; do not replace them with zero. Values represent the amounts and rates in the supplied quote, not independently inferred tax rules.

```json
{
  "quotes": [
    {
      "id": "q-a",
      "vendor": "Example Supplier A",
      "currency": "USD",
      "reference": "Quote A, page 1",
      "validUntil": "2027-01-31",
      "leadDays": 7,
      "shipping": "25.00",
      "fees": "10.00",
      "discountPercent": "0",
      "taxRate": "5",
      "taxBase": "items+fees",
      "notes": "Installation excluded. Payment due on delivery.",
      "items": [
        {
          "id": "line-a1",
          "description": "Printed signs",
          "quantity": "20",
          "unit": "each",
          "unitPrice": "12.50",
          "optional": false
        },
        {
          "id": "line-a2",
          "description": "Mounting hardware",
          "quantity": "20",
          "unit": "each",
          "unitPrice": "1.25",
          "optional": true,
          "included": false
        }
      ]
    }
  ]
}
```

## Calculation fields

| Field | Meaning |
| --- | --- |
| `id` | Unique quote identifier. |
| `vendor` | Supplier name. |
| `currency` | USD, CAD, EUR, GBP, AUD, NZD, JPY, CHF, SEK, NOK, DKK, PLN, CZK, MXN, SGD, HKD, KWD, or BHD. |
| `reference` | Source quote/page/row identifier. |
| `validUntil` | Price validity date as `YYYY-MM-DD`, when stated. |
| `leadDays` | Stated lead time in calendar days; leave null when unknown. |
| `shipping`, `fees` | Separate fixed shipping/delivery and other fees. |
| `discountPercent` | Discount on included line items, from 0 to 100. |
| `taxRate` | Explicit tax percentage, from 0 to 100. |
| `taxBase` | `items`: discounted items; `items+fees`: discounted items and fees; `all`: discounted items, fees, and shipping. Set this explicitly from the quote. |
| `notes` | Inclusions, exclusions, warranty, payment terms, deposits, and source notes. These are descriptive, not added to the arithmetic. |
| `items[].description` | Source item description. |
| `items[].quantity`, `unit`, `unitPrice` | Positive quantity, stated unit, and nonnegative price per unit. |
| `items[].optional`, `included` | Optional items count only when `included` is true. Ordinary items count automatically. |

The engine rounds each included line to the currency's minor unit, applies the percentage discount to their subtotal, then computes tax on the chosen base. Total is discounted subtotal plus fees, shipping, and tax. Confirm that this matches the supplier's calculation method. Preserve the supplier's stated total separately in the comparison to expose rounding or transcription differences.

Keep recurring amounts in a separate, clearly labelled scenario or comparison. Do not add a monthly price to a one-time project total. Deposits usually change cash timing rather than the total price; do not add them as extra fees unless the source says they are additional charges. Extract them into the presentation from `notes` and the original documents.

For optional-item scenarios, copy the input, change `included` for the relevant optional items, and rerun. Preserve the base scenario. Scopes are considered equivalent only when normalized descriptions, quantities, and units match; inspect meaningful source differences even when this mechanical comparison succeeds.

## CSV

Use one row per item. Repeat quote-level values identically on each row sharing a quote `id`.

Required headers: `id,vendor,currency,description,quantity,unit,unitPrice`.

Additional supported headers: `reference,validUntil,leadDays,shipping,taxRate,taxBase,fees,discountPercent,notes,itemId,optional,included`.

Use `true`/`false` or `1`/`0` for booleans. A blank optional/included value is false. Quote commas, double quotes, or embedded line breaks using standard CSV escaping. Missing monetary fields remain unknown, which prevents a complete total.

## Output

The JSON result contains `asOf`, `groups`, and overall `issues`. Each currency group contains calculated quote rows, a scope comparison, and scope notes. Each row provides `subtotal`, `discountAmount`, `shipping`, `fees`, `tax`, `total`, `complete`, `issues`, `questions`, and calculated `lines`. Quotes with unknown or invalid calculation fields have `total: null`. Read the reasons before recommending a supplier. Scope signatures support matching; they are not a substitute for reading terms.

The engine accepts at most 100 quotes, 1,000 included items per quote, and 10 MB of CSV.
