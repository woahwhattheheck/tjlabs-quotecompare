# Hosted basket and pack comparison

Use the hosted tools `compare_supplier_quotes` and `export_quote_comparison` for explicit purchase requirements, pack sizes, supplier minimums and order increments. Their argument object uses `as_of`, `requirements`, and `quotes`; it is different from the bundled local script's quote-row format.

Use the full synthetic example in [pack-example.json](../assets/pack-example.json) as an input-shape example. Update `as_of` to the actual comparison date. Preserve a source quote's real validity date rather than refreshing it automatically.

## Requirements

Each requirement has `item_id`, a positive decimal-string `quantity`, and an explicit `unit`. Use `label` and `source` to preserve what the buyer asked for. Match each supplier line to the appropriate requirement using `item_id`; do not assert equivalence between different products just because their units match.

## Quotes and lines

Each quote has `quote_id`, `supplier`, `currency`, and `lines`, plus its known `valid_until`, `source`, `shipping`, `fees`, `discount_percent`, `tax`, and `unresolved_terms`.

Each line has:

| Field | Meaning |
| --- | --- |
| `line_id`, `item_id` | Unique line identifier and its matching buyer requirement. |
| `pack_quantity`, `unit` | Explicit amount of a stated unit in one purchasable pack. |
| `price_per_pack` | Exact decimal-string price for one whole pack; null when unknown. |
| `minimum_packs` | Supplier's minimum number of packs. |
| `order_increment_packs` | Order quantities must be absolute multiples of this many packs. |
| `discount_percent` | Explicit line discount as decimal text, or null when unknown. |
| `source` | Source label and optional locator, excerpt, or public source URL. |

All decimal amounts and quantities are strings, not JSON floating-point numbers. Keep unknown terms null. An explicit source establishing zero or no charge supports zero. Line discounts apply before the separate order discount.

Supported units include each/ea/piece/pieces, mg/g/kg/lb/oz, ml/l, explicit US or imperial fluid ounces/gallons, and mm/cm/m/in/ft. Keep mass, volume, and length distinct. Never infer density to turn gallons into kilograms.

`shipping` is an object with `amount` and optional `source`. `fees` is an array of labelled amounts and sources; use [] only when the source establishes no extra fees. `tax.mode` is `none`, `inclusive`, `exclusive`, `amount`, or `unknown`; provide its stated rate or fixed amount and explicit `applies_to_shipping`/`applies_to_fees` where applicable. Keep source tax treatment intact.

## Interpret the result

Show the required quantity, packs ordered, actual quantity supplied, oversupply, stated charges, and calculated total. Preserve unresolved terms and reasons a quote is excluded from ranking. Group currencies separately. A calculated lowest total is useful only for matching products and requirements; explain remaining scope differences from the source documents.

The export tool returns a filename, MIME type and CSV text. Save that text as the stated CSV file and inspect the resulting headers and data before handing it to the buyer. The current service accepts up to 50 supplier quotes, subject to its request/response size limits; the paid manual fulfillment offer has its own agreed commercial scope.
