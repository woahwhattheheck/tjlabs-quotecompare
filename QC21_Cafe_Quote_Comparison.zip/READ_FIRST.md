# Cafe cup-order comparison

**Open `workbench.html` for the editable comparison.** The supplied order is already loaded. This is a fictional example, compared as of **26 October 2026**, in **USD**.

## Purchasing choice

**Birch Wholesale has the lowest fully priced offer: $45.36 for 360 cups.** It satisfies the 300-cup requirement with 60 extra cups and requires $25.00 less cash than Alder.

Cedar could cost less, but its delivered price is still incomplete. Its 300 cups cost $27.00 including tax before the unconfirmed freight. Cedar beats Birch only if its final additional freight charge, including any tax on that freight, is **below $18.36**. At $18.36, its delivered total ties Birch at $45.36.

| Supplier / quote | Packs to order | Cups received | Extra cups | Merchandise after both discounts | Freight | Other fees | Added tax | Complete order total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Alder Supply / A-1026 | 6 × 100 | 600 | 300 | $51.30 | $12.00 | $2.00 handling | $5.06 | **$70.36** |
| Birch Wholesale / B-1026 | 3 × 120 | 360 | 60 | $42.00 | $0.00, included | $0.00 | $3.36 | **$45.36** |
| Cedar Paper / C-1026 | 3 × 100 | 300 | 0 | $27.00, tax included | **Unknown** | $0.00 | Included in pack price | **Unknown** |

All three quotes describe the same clear, 16-ounce cup model and material. **Lids are excluded.** All three are valid through **15 November 2026**.

## Why the quantities and totals differ

**Alder:** The requirement alone needs three packs, but the minimum is five and the order must be an absolute multiple of two packs. The smallest valid order is therefore six packs. The calculation is $60.00 less the 10% line discount = $54.00; then less the separate 5% order discount = $51.30. Tax applies to $51.30 merchandise plus $12.00 freight: 8% × $63.30 = $5.064, rounded to $5.06. Handling is not taxed. The total is $51.30 + $12.00 + $2.00 + $5.06 = $70.36. The two discounts combine to 14.5%, not 15%.

**Birch:** Three packs provide 360 cups. Merchandise is 3 × $14.00 = $42.00; merchandise tax is $3.36. Freight is explicitly included and there are no other fees, giving $45.36.

**Cedar:** Three packs provide exactly 300 cups for $27.00, with tax already in the pack price. An unknown freight amount remains unknown in the project and total. No freight charge has been substituted with zero.

Alder's full cost per received cup is about 11.73 cents, versus Birch's 12.60 cents. Alder requires an additional $25.00 and supplies 240 more cups than Birch. For the stated 300-cup need and cash objective, Birch is the stronger fully priced option; future demand for the extra inventory was not supplied.

## Terms that could change the choice

The specific outstanding pricing question is Cedar's final freight charge, including any applicable tax on it. A usable clarification would be:

> Please confirm the total delivered price for three packs, 300 cups, under C-1026, including freight and any tax on freight. The quoted pack cost is $27.00 including tax.

The sources do not specify a payment due date or delivery date. Add those details if they affect when the cafe needs to pay or receive the order.

## Use the editable files

- **workbench.html:** Open locally, change quantities or supplier terms, then calculate. No server or installation is needed. Use **Download project** to keep edits and **Print / save PDF** for a shareable comparison.
- **project.json:** The full source-bearing input. Reopen it in the workbench to resume saved work.
- **comparison.csv:** The calculated snapshot. Editing its cells does not recalculate the order. Its `line_subtotal` and `line_unit_cost_excl_order_charges` are after the line discount and before the separate order discount, freight, fees and tax; `quote_total` is the full order total when known.

When Cedar confirms freight, enter the confirmed amount and update its source note. Resolve the corresponding **Other unresolved terms** entry only when its tax treatment is clear, then calculate again.

## Source record

The complete supplied wording is preserved as source-bearing project fields:

- Purchasing request: 300 clear, 16-ounce cold cups; equivalent model/material; lids excluded.
- Alder Supply, A-1026, page 1.
- Birch Wholesale, B-1026, page 2.
- Cedar Paper, C-1026, email dated 26 October 2026.

Calculations use the packaged local QuoteCompare engine. Monetary lines, discounts and tax are rounded half up to cents.

